import json


def render(diffed):
    return json.dumps(diffed)
