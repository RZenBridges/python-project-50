from gendiff.scripts.gendiff import generate_diff, format_of_choice


__all__ = (generate_diff, format_of_choice)
