from gendiff.scripts.gendiff import generate_diff, format_of_choice


__version__ = '1.0'

__all__ = (generate_diff, format_of_choice, __version__)
