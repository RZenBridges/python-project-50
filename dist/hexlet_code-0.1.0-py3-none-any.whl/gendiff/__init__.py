from gendiff.diff_calc import generate_diff


__version__ = '1.0'

__all__ = (generate_diff, __version__)
