#!/usr/bin/python3
from gendiff.gendiff_main import call_gendiff


def main():
    call_gendiff()


if __name__ == "__main__":
    main()
