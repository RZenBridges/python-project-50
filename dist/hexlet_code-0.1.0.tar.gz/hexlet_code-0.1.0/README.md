### Hexlet tests and linter status:
[![Actions Status](https://github.com/RZenBridges/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/RZenBridges/python-project-50/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/5cbf8d32c7a2e745dlb2/maintainability)](https://codeclimate.com/github/RZenBridges/python-project-50/maintainability)

See how gendiff works at the link:
https://asciinema.org/a/tYrAU3IkT4gWEecq60rpZsx8x
