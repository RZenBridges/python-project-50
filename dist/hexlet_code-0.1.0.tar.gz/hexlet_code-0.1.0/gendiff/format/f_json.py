import json


def jsonify(diffed):
    return json.dumps(diffed)
